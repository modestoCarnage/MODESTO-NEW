import React from "react";
import { SignInRow } from "./_components/sign-in";

const SignInPage = () => {
  return <SignInRow />;
};

export default SignInPage;
